# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

defmodule FlagdUi.Mailer do
  use Swoosh.Mailer, otp_app: :flagd_ui
end
