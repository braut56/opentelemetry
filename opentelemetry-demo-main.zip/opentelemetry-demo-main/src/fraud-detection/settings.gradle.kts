
rootProject.name = "fraud-detection"

